
package packageJava.NumeroDecimal;


public class MainApp {

    public static void main(String[] args) {
    
            DecimalnUM.decimalVerified();
      
    }
    
}
