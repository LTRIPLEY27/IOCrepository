package packageJava.Androide;
public interface Verifica {
    public void sirveComida();
    public void sirveCafe();
    public void limpiar();
    public void recoge();
    public void pasearPerro();
    public void acunarBebe();
    public void lavarRopa();
}
