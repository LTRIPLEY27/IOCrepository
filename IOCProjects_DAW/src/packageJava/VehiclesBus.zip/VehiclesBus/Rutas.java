
package packageJava.VehiclesBus;

import java.util.Scanner;

public interface Rutas {
    
    public  void recorrido();
   // public void horario();
    final Scanner ASK = new Scanner(System.in);
}
