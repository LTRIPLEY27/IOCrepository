
package packageJava.AndroideVersion2;

public class MazingerZ extends Androides {

    public MazingerZ(int respuesta) {
        super(respuesta);
    }
    
    
}
