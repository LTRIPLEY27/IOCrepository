package packageJava.AndroideVersion2;

public class AndroideT800 extends Androides{

    public AndroideT800(String year, String human, String name) {
        super(year,human, name);
    }
    
}
