
package packageJava.AndroideVersion2;

public class Data extends Androides{

    public Data(int player, int players) {
        super(player, players);
    }
    
}
