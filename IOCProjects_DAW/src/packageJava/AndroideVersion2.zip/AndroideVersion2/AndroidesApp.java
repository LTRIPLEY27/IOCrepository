package packageJava.AndroideVersion2;

import java.util.Scanner;
import javax.swing.JOptionPane;
import packageJava.Androide.Androide;

/**
 *
 * @author isabe
 */
public class AndroidesApp {

    public static void main(String[] args) {
       Vista.startProgram();
    }
}
