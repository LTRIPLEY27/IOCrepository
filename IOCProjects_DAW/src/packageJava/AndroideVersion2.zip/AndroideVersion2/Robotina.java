package packageJava.AndroideVersion2;

public class Robotina extends Androides{

    public Robotina() {
        super();
    }
    
}
