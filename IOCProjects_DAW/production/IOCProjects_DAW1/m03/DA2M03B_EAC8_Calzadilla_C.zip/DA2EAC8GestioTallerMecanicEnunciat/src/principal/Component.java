/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package principal;

import java.util.Scanner;

/**
 *
 * @author hellz // INTERFACE COMPONENT CON LOS METODOS DEMANDADOS
 */
public interface Component {
    public final static Scanner DADES = new Scanner(System.in);
    
    public void updateComponent();
    public void showComponent();
}
